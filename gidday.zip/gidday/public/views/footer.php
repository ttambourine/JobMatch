<?php
echo "
		<div class='footer'>
		<div class='footBox'>
			<div class='leftShare'>
				<a href='/' class='footerTop'><h5>Home</h5></a>
			</div>
			<div class='share'>
				<h5>Browse Jobs</h5>
				<h6>Your Matches <br>
					Job Search
				</h6> 
			</div>
			<div class='share'>
				<h5>Submit a Job</h5>
				<h6>Post a Job
				</h6>
			</div>
			<div class='share'>
				<h5>Profile</h5>
				<h6>Profile <br>
					Preferences <br>
					History
				</h6>
			</div>
			<div class='share'>
				<a href='/about' class='footerTop'><h5>Help</h5></a>
				<a href='/about' class='footerBot'><h6>About</a> <br>
					Tutorial <br>
					<a href='/faq'class='footerBot'>FAQ </a><br>
					<a href='/contact'class='footerBot'>Contact Us</a>
				</h6>
			</div>
		</div>
		</div>
";
?>