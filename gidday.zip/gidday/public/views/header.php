<?php
echo" 
		<div class='navBar'>
			<div class='box'>
				<a href='/' class='JobMatch'><h1> JobMatch </h1></a>
			</div>
			<div class='leftLinks'>
				<a href='https://laravel.com/docs' class='mainLink'>Browse Jobs</a>
				<div class='gap'></div>
				<a href='https://laracasts.com' class='mainLink'>Submit a Job</a>
			</div>
			<div class='rightLinks'>
				<a href='/about' class='secondLink'>Help</a>
				<div class='gap'></div>
				<a href='https://laracasts.com' class='secondLink'>Sign Up</a>
				<div class='gap'></div>
				<a href='https://laracasts.com' class='secondLink'>Login</a>
			</div>
		</div>
";
?>