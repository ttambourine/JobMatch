<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Jobmatch</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
              html {
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
			
			.headerBar {
				padding-top: 25px;
			}
			
			.linkBox {
				background-color: #E5E5E5;
				padding-top: 10px;
				padding-bottom: 10px;
			}
			.pageBox {
				margin: 25px; 
                align-items: center;
                display: flex;
                justify-content: center;
				background-color: #E5E5E5;
				border-style: solid; 
				border-color: #a0a0a0;
			}
			.aboutBox {
				width: 80%;
				margin: 0 auto;
				padding-top: 20px;
				padding-bottom: 20px;
			}
        </style>
		
		<div class="headerBar">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>
                        <a href="<?php echo e(route('register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">
                    JobMatch
                </div>

                <div class="linkBox">
					<div class="links">
						<a href="https://laravel.com/docs">Home</a>
						<a href="https://laracasts.com">Open Jobs</a>
						<a href="https://laravel-news.com">Register a Job</a>
						<a href="https://forge.laravel.com">Your Profile</a>
						<a href="http://localhost:8000/about">About</a>
					</div>
				</div>
            </div>
        </div>
    </head>
    <body>

    </body>
</html>
