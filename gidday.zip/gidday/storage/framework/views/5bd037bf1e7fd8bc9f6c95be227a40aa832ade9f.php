<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Jobmatch</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            head {
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

			body {
				background-image: url("http://cityillustration.com/wp-content/uploads/2013/06/melbourne-pen.jpg");
				background-repeat: no-repeat;
				background-position: bottom;
				height:100vh;
			}
			
            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }
			a:hover {
				background-color: #f1f1f1;
			}

            .m-b-md {
                margin-bottom: 30px;
            }
			
			.headerBar {
				padding-top: 25px;
			}
			
			.linkBox {
				background-color: #E5E5E5;
				padding-top: 10px;
				padding-bottom: 10px;
				margin-bottom: 25px;
			}
			
			.pageBox {
				margin: 0 auto; 
				width: 80%;
                justify-content: center;
				background-color: #e9e9e9;
			}
			.aboutBox {
				width: 80%;
				margin: 0 auto;
				padding-top: 20px;
				padding-bottom: 20px;
				text-align: justify;
			}
			.footer {
				position: absolute;
				right: 0;
				bottom: 0;
				left: 0;
				background-color: #efefef;
				text-align: center;
			}
			.footerLinkBox {
				right: 0;
				bottom: 0;
				left: 0;
				background-color: #efefef;
				text-align: center;
				background-color: #E5E5E5;
				padding-top: 10px;
				padding-bottom: 10px;
				margin-top: 25px;
			}
        </style>
		
		<div class="headerBar">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>
                        <a href="<?php echo e(route('register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">
                    JobMatch
                </div>

                <div class="linkBox">
					<div class="links">
						<a href="https://laravel.com/docs">Home</a>
						<a href="https://laracasts.com">Open Jobs</a>
						<a href="https://laravel-news.com">Register a Job</a>
						<a href="https://forge.laravel.com">Your Profile</a>
						<a href="http://localhost:8000/about">About</a>
					</div>
				</div>
            </div>
        </div>
    </head>
    <body>
        <div class="pageBox" >
			<div class="aboutBox" >
				<h2> About Jobmatch</h2> 
					<p> 
						Jobmatch is a task matching website designed to promote available jobs submitted by our community, and then from our pool of community job seekers 
						who have created their profiles, including experience, qualifications, pay expectations, and more details, our JobMatch Algorithm™ will work its 
						stuff and will fill an applicant pool automatically with Job Seekers who have marked themselves as actively looking for jobs, and will email the 
						applicants about the possible JobMatch if they prefer to apply directly! 
					</p>
					<p>
						From here, the poster of the application will be able to see and review all of the matched workers that our JobMatch Algorithm™ has matched their 
						job with, given the information they've added. At this point the employer can see who has applied, as well as their pay expectations, community rating 
						from past jobs, as well as more details reviews left by past clients. 
					</p>
				<h2> Why should you choose Jobmatch? </h3> 
					<p>
						Jobmatch is a job matching service for the people! Whether for working on the side, or a full time JobMatch worker you'll appreciate our features such as 
						being able to set how much you'd like to get paid for a job, how many kilometres away you are willing to work, and your available hours. This means you 
						wont get bombarded with irrelevant emails from us, we will only notify when we find the right job for you! 
					</p>
				<h2> Mission Statement </h3> 
					<p>
						We here at JobMatch want to create an experience that is easy for you, the user! Whether advertising or auditioning we want our site to be an easy
						first stop for anyone trying to find work. 
					</p>
			</div>
		</div>
				<div class="footerLinkBox">
					<div class="links">
						<a href="https://laravel.com/docs">About</a>
						<a href="https://laracasts.com">FAQ</a>
						<a href="https://laravel-news.com">How To Use</a>
						<a href="https://forge.laravel.com">Privacy</a>
						<a href="http://localhost:8000/about">Contact Us</a>
					</div>
				</div>
    </body>
</html>
